﻿// Please see documentation at https://docs.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your JavaScript code.

AddRow = function (employee) {
    $.post('/Employees/PhonePartialView', { employeeViewModel: employee, delete: false }, function (data) {
        $("#phoneList").html(data);
    });
};

DeleteRow = function (employee) {
    $.post('/Employees/PhonePartialView', { employeeViewModel: employee, delete: true }, function (data) {
        $("#phoneList").html(data);
    });
};